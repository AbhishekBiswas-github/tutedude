-- Use LEFT JOIN to List Employees and Their Managers
SELECT
	e.employee_id,
    CONCAT(e.first_name, ' ', e.last_name) AS "Employee's Name",
    e.job_title,
    e.salary,
    CONCAT(m.first_name, ' ', m.last_name) AS "Manager's Name"
FROM employees e
LEFT JOIN employees m
	ON e.manager_id = m.employee_id
ORDER BY e.employee_id;



-- Subquery for Employees Earning Above Average Salary
SELECT
	e.employee_id,
    CONCAT(e.first_name, ' ', e.last_name) AS "Employee's Name",
    e.salary
FROM employees e
WHERE e.salary > (
	SELECT
		AVG(salary) AS "Avg Salary"
	FROM 
		employees
)
ORDER BY e.salary;


-- Nested JOIN to Get Employee Name, Department, and Company
SELECT 
	e.employee_id AS "ID",
	CONCAT(e.first_name, ' ', e.last_name) AS "Employee's Name",
    d.department_name AS "Department Name",
    c.company_name AS "Company Name"
FROM employees e
JOIN departments d
	ON d.department_id = e.department_id
JOIN companies c
	ON c.company_id = d.company_id
ORDER BY c.company_name, d.department_name, e.employee_id;


-- Use a CTE to Find the Second-Highest Salary
WITH salary_rank AS (
	SELECT 
		*,
        DENSE_RANK() OVER (ORDER BY salary DESC) AS salary_rank
	FROM 
		employees
)
SELECT
	salary_rank,
	employee_id,
    CONCAT(first_name, ' ', last_name) AS "Employee's Name",
    job_title,
    salary
FROM 
	salary_rank
WHERE salary_rank = 2;


-- Rank Employees by Salary Within Departments
SELECT 
	e.employee_id AS "ID",
	CONCAT(e.first_name, ' ', e.last_name) AS "Employee's Name",
    d.department_name AS "Department Name",
    e.salary AS "Salary",
	RANK() OVER (ORDER BY e.salary DESC) as "Salary Rank"
FROM employees e
JOIN departments d
	ON d.department_id = e.department_id;
        

-- Categorise Employees as 'Low', 'Medium', or 'High' Earners
SELECT
	employee_id,
    CONCAT(first_name, ' ', last_name) AS "Employee's Name",
    job_title,
    salary,
    CASE 
		WHEN salary < 70000 THEN "Low Earners"
        WHEN salary BETWEEN 70000 AND 100000 THEN "Medium Earners"
        ELSE "High Earners"
	END AS salary_category
FROM employees
ORDER BY salary DESC;
        
        
        
        
        
        
        
        
        
        