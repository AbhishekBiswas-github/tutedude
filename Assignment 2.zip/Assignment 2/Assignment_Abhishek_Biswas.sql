-- Retrieve all employees 
SELECT * FROM employees;

-- Sales Employee
SELECT employees.* FROM employees
WHERE job_title REGEXP '.*Sales.*';

-- Unique job titles
SELECT distinct(job_title) AS "Unique job titles" FROM employees;


-- sort employees based on salary
SELECT concat(first_name, CONCAT(" ", last_name)) AS "Name", salary FROM employees
ORDER BY salary DESC;

-- Total number of employees
SELECT COUNT(employee_id) AS "Total Employees" FROM employees;

-- Agerage Department Salary
SELECT department_name AS "Department Name", ROUND(avg(salary), 2) AS "Average Salary" FROM employees
JOIN departments
ON employees.department_id = departments.department_id
GROUP BY department_name;

-- Employee name and department name
SELECT concat(first_name, CONCAT(" ", last_name)) AS "Name", department_name AS "Department Name" FROM employees
JOIN departments
ON employees.department_id = departments.department_id
