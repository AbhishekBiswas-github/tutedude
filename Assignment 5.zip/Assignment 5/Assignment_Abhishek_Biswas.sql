-- employee data
SELECT * FROM employees;


-- Transaction to Transfer Salary
START TRANSACTION;

UPDATE employees
SET  salary = salary - 1000
WHERE employee_id = 1006
AND salary >= 1000;

UPDATE employees 
SET salary = salary + 1000
WHERE employee_id = 1011;

COMMIT;


-- Departments with Employees
SELECT 
	d.department_id,
    d.department_name,
    d.company_id
FROM departments d
WHERE EXISTS (
	SELECT 1 
    FROM employees e
    WHERE e.department_id = d.department_id
);


-- Recursive CTE for Employee-Manager Hierarchy
WITH RECURSIVE EmployeeHierarchy AS (
   SELECT
       employee_id,
       CONCAT(first_name, ' ', last_name) AS employee_name,
       manager_id,
       job_title,
       0 AS hierarchy_level,
       CAST(CONCAT(first_name, ' ', last_name) AS CHAR(1000)) AS hierarchy_path
   FROM employees
   WHERE manager_id IS NULL
   UNION ALL

   SELECT
       e.employee_id,
       CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
       e.manager_id,
       e.job_title,
       eh.hierarchy_level + 1 AS hierarchy_level,
       CONCAT(eh.hierarchy_path, ' -> ', e.first_name, ' ', e.last_name) AS hierarchy_path
   FROM employees e
   INNER JOIN EmployeeHierarchy eh
       ON e.manager_id = eh.employee_id
)
SELECT 
	employee_id, 
    employee_name,
    manager_id, 
    job_title,
    hierarchy_path
FROM EmployeeHierarchy
ORDER BY hierarchy_path;


-- LEAD and LAG for Salaries
SELECT
   employee_id,
   CONCAT(first_name, ' ', last_name) AS employee_name,
   job_title,
   LAG(salary) OVER (ORDER BY salary) AS previous_salary,
   salary,
   LEAD(salary) OVER (ORDER BY salary) AS next_salary
FROM employees
ORDER BY salary;


-- Salary Totals with ROLLUP
SELECT
   d.department_name,
   SUM(e.salary) AS total_salary
FROM employees e
JOIN departments d
   ON e.department_id = d.department_id
GROUP BY d.department_name WITH ROLLUP;














