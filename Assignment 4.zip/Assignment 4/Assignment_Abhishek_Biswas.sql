-- Update the Salary of Employees in the 'Sales' Department by 10%
Update employees e
Join departments d
	ON e.department_id = d.department_id
SET e.salary = e.salary * 1.10
WHERE d.department_name = "Sales & Marketing";


-- Delete Employees Working in a Department Named 'Obsolete'
DELETE e 
FROM employees e
JOIN departments d
	ON e.department_id = d.department_id
WHERE department_name = "Clinical Operations";

-- Create a View Showing High-Earning Employees (Salary > 80,000)
CREATE VIEW high_earning_employees AS 
SELECT 
	employee_id,
    CONCAT(first_name, ' ', last_name) AS "Employee's Name",
    job_title,
    salary,
    department_id,
    hire_date
FROM employees
WHERE salary > 80000;

SELECT * FROM high_earning_employees;



-- Add a CHECK Constraint to Ensure Salary > 0
ALTER TABLE employees
ADD CONSTRAINT chk_salary_positive
CHECK (salary > 0);


-- Create an Index on Employee Last Names for Faster Searching
CREATE INDEX inx_employees_last_name
ON employees(last_name);


-- Create a Stored Procedure to Retrieve Employees of a Given Department
CREATE INDEX inx_employees_last_name_new
ON employees(last_name);

DELIMITER $$
CREATE PROCEDURE GetEmployeesByDepartment( IN dept_name VARCHAR(255))
BEGIN
	SELECT
		e.employee_id,
        CONCAT(e.first_name, ' ', e.last_name) AS "Employee's Name",
        e.job_title,
        e.salary,
        e.hire_date,
        d.department_name
	FROM employees e
    JOIN departments d
		ON e.department_id = d.department_id
	WHERE d.department_name = dept_name
    ORDER BY e.salary DESC;
END $$
DELIMITER ;















